from django.contrib import admin
from .models import Contact , Donate

class Admin_contact(admin.ModelAdmin):
    list_display=('name','email','phone')
admin.site.register(Contact, Admin_contact)

class Admin_donate(admin.ModelAdmin):
    list_display= ('name','email','address','city','state')
admin.site.register(Donate, Admin_donate)