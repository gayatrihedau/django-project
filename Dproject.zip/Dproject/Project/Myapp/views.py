import email
from django.shortcuts import render
from Myapp.models import Contact , Donate

def home(request):
    return render(request,'home.html')
def about(request):
    return render(request,'about.html')
def gallery(request):
    return render(request,'gallery.html')
def contact(request):
    if request.method=='POST':
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        concern=request.POST['concern']
        print(name,email,phone,concern)
        obj=Contact(name=name,email=email,phone=phone,concern=concern)
        obj.save()
        
    return render(request,'contact.html')



def donate(request):
    if request.method=='POST':
        name=request.POST['name']
        email=request.POST['email']
        address=request.POST['address']
        city=request.POST['city']
        state=request.POST['state']
        print(name , email, address, city, state)
        obj=Donate(name=name,  email=email, address=address, city=city, state=state)
        obj.save()
    return render(request,'donate.html')